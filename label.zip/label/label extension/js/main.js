const searchSVG = `<svg aria-labelledby="title desc" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.9 19.7" stroke-width="2" width="20" height="20"><g class="search-path" fill="white" stroke="#000"><path stroke-linecap="square" d="M18.5 18.3l-5.4-5.4"/><circle cx="8" cy="8" r="7"/></g></svg>`;
var newarray = [];
var labelInputDiv;
var token;
const initLabelStyle = () => {
    var labelMenuItem = document.createElement("div");
    labelMenuItem.setAttribute('class', 'dropdown');
    
    var labelButton = document.createElement("div");
    labelButton.innerHTML = searchSVG;
    labelButton.setAttribute('class', 'dropbtn');
    //getlabelName();
   // location.reload(true);
    labelButton.addEventListener('click', async function() {
        var users 
       await getlabelName();
       
        window.location.reload();
        //window.stop();
        document.getElementById("myDropdown").classList.toggle("show");
    });
    labelMenuItem.appendChild(labelButton);

    labelInputDiv = document.createElement("div");
    labelInputDiv.setAttribute('class', 'dropdown-content');
    labelInputDiv.setAttribute('id', 'myDropdown');
    labelMenuItem.appendChild(labelInputDiv);
 
    var labelInput = document.createElement("input");
    labelInput.setAttribute('type', 'text');
    labelInput.setAttribute('placeholder', 'search label..');
    labelInput.setAttribute('id', 'myInput');
    labelInput.addEventListener('keyup', function() {
        filterFunction();
    });
    labelInputDiv.appendChild(labelInput);
    


    window.onclick = function(event) {
        console.log(event.target)
        if (!event.target.matches('#myInput') && !event.target.matches('circle')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                 }
             }
        }
    }

    return labelMenuItem;
}



function filterFunction() {
    let input = document.getElementById("myInput");
    let div = document.getElementById("myDropdown");
    let filter = input.value.toLowerCase();
    console.log(filter)
    let a = div.querySelectorAll("a.lnksearchkey");
    for (let i = 0; i < a.length; i++) {
        let txtValue = a[i].textContent.toLowerCase();
        if (txtValue.indexOf(filter) >= 0) {
            console.log(txtValue, txtValue.indexOf(filter))
            document.querySelector('a.lnksearchkey[data-value=' + txtValue + ']').classList.remove('hide-element');
        } else {
            document.querySelector('a.lnksearchkey[data-value=' + txtValue + ']').classList.add('hide-element');
        }
    }
}



const getlabelName = async() => {
   // chrome.storage.local.get(["token"]).then((result) => {
    token = await chrome.runtime.sendMessage('authorization');
        let init = {
            method: 'GET',
            async: true,
            headers: {
                Authorization: 'Bearer ' + token,
                'Content-Type': 'application/json'
            },
            'contentType': 'json'
        };
        chrome.storage.local.get(["userId"]).then((result) => {
            var emailId = result.userId;
            
            // first = true,
            //window.location.reload();
            labelEmail(emailId, init);
        });
 //   });
// window.location.reload();
//if (alert ('Alert For your User!')) {} else window.location.reload ();
}


 async function labelEmail(emailId, init) {
    //console.log("111",first)
    const label = await fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/labels', init);
    const labelData = await label.json();
        // .then((response) => response.json())
        // .then(function(data) {
            labelData.labels.forEach(element => {
                newarray.push(element.name);
            });
            
            var labelOption = document.createElement("a");
            labelOption.innerHTML = '&nbsp;';
            labelInputDiv.appendChild(labelOption);

            for (let index = 0; index < newarray.length; index++) {
                labelOption = document.createElement("a");
                labelOption.classList.add('lnksearchkey');
                labelOption.setAttribute('data-value', newarray[index].toLowerCase());
                labelOption.addEventListener('click', function() {
                    //var typeText = document.querySelector('input.gb_if.aJh,input.gb_jf.aJh,input.gb_Te.aJh,input.gb_Ue.aJh');
                    var typeText = document.querySelector('input[aria-label="Search in mail"]');
                    typeText.value = "label:" + newarray[index];
                    var searchIcon = document.querySelector('.gb_rf.gb_sf,.gb_sf.gb_tf,.gb_3e.gb_4e,.gb_4e.gb_5e');
                    searchIcon.click();
                });
                labelOption.innerHTML = newarray[index];
                labelInputDiv.appendChild(labelOption);
            }
            labelInputDiv = "";
       // });

       // if (alert ('Alert For your User!')) {} else window.location.reload ();

        // if (sessionStorage.getItem('reloaded') != null) {
        //      console.log('page was reloaded'); 
        //     } else { 
        //         console.log('page was not reloaded'); 
        //     } 
        //     sessionStorage.setItem('reloaded', 'yes'); // could be anything
        //alert("Reload this page")

        // window.location.reload();
        // window.stop();

        // if(first===true){
        //     console.log("222",first)
        //     window.location.reload();
        // }
        // first = false;
        // console.log("333",first)
}





const initExtraStyling = (Labelelem) => {
    var Labeldvelem = document.createElement("div");
    Labeldvelem.classList.add('aAw');
    Labeldvelem.classList.add('FgKVne');
    Labeldvelem.appendChild(initLabelStyle());
    Labelelem.appendChild(Labeldvelem);
}



const initLabelTemplate = () => {
    var Labelinterval = setInterval(function() {
        var Labelelem = document.querySelector('.aAw.FgKVne');
        if (Labelelem) {
            clearInterval(Labelinterval);
            initExtraStyling(Labelelem);
        }
    }, 100);
   
}



const init = async () => {
    initLabelTemplate();
   
}

const main = async () => {
    await init();
}

main();
